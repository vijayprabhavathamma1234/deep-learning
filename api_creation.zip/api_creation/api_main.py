from flask import Flask, request, jsonify
from flask_cors import CORS
 
from task_rag.task_api import give_task_list as give_list
from agentic_code.quality_agent import *
from flask_socketio import SocketIO
# from agentic_code.agent import fetch_query_answers_from_pdf

#  .venv\Scripts\activate
#  cd RL_Project1\Ralph_Lauren_v2\api_creation
# http://127.0.0.1:5000/task_execute

# python api_main.py
 
 
app = Flask(__name__)
CORS(app)
socketio = SocketIO(app, cors_allowed_origins="http://localhost:3001")
 
logs = []  # List to store logs
 
@socketio.on('connect')
def handle_connect():
    print('Client connected')
 
def emit_log(log_entry):
    socketio.emit('log', log_entry)
 
@app.route('/call_function', methods=['POST'])
def call_function():
    query = request.json.get('query')
    res = give_list(query)
    # log_entry = f"call_function: {res}"
    # socketio.emit('log', log_entry)  
    return jsonify(res)
 
@app.route('/task_execute', methods=['GET', 'POST'])
def task_execute():
    if request.method == 'POST':
        query = request.json.get('query')
        print(query)
        res = user_prompt(query)
        log_entry = f"call_function: {query}"
        log_entry1 = f"compliance: {res}"
        socketio.emit('log', log_entry1)
        return jsonify(result=res)
    else:
        return jsonify({'error': 'Method Not Allowed'}), 405

@app.route('/emit_log', methods=['POST'])
def handle_emit_log():
    log_entry = request.json.get('log_entry')
    if log_entry:
        emit_log(log_entry)
        return jsonify({'success': True})
    else:
        return jsonify({'success': False, 'error': 'Log entry missing'}), 400

@app.route('/get_logs', methods=['GET'])
def get_logs():
    return jsonify(logs)
 

 
if __name__ == '__main__':
    socketio.run(app)



# from flask import Flask, request, jsonify

# from task_rag.task_api import give_task_list as give_list
# from agentic_code.quality_agent import *
# app = Flask(__name__)


# @app.route('/call_function', methods=['POST'])
# def call_function():
#     query = request.json.get('query')
#     res=give_list(query)
#     return jsonify(result=res)


# @app.route('/task_execute', methods=['POST'])
# def task_execute():
#     query = request.json.get('query')
#     res=user_prompt(query)
#     return jsonify(result=res)


# if __name__ == '__main__':
#     app.run(debug=True)





# ## query 

# "Give me the steps performed for the checking attendance file 'Are employees accurately recording their working hours, both in-office and work-from-home (WFH), and are there any discrepancies that need to be addressed?'"
# "Give me the steps performed for the checking ask_hr file 'How are the annual leave categories divided at Prolifics?'"
# "Give me the steps performed for the checking ask_hr file 'How does Prolifics handle leave requests during the notice period?'"

# "Give me the steps performed for the checking ask_hr file 'What is the special leave entitlement for male employees who adopt a child between 3 to 5 years old?'"



# # "Give me the steps performed for the checking RAID Register file 'Are Issue Logs being maintained, updated and issues tracked to closure?'"
# # "Give me the steps performed for the checking RAID Register file 'Are risks being reported to the Senior Management as per agreed frequency and tracked to closure?'"    
# # "Give me the steps performed for the checking RAID Register file 'Are all Risks and Opportunities for the project being identified, analysed, documented and Response action initiated?'"
# # "Give me the steps performed for the checking Kick-off file 'Is Project Kick-Off Meeting conducted with all the stakeholders and minutes documented? Is the Kick-off presentation available in the project repository? Are all the activities applicable for the project initiation been completed?'"
# # "Give me the steps performed for the checking CAR file 'Are causal analysis plan documented with selection of types of outcomes for Root cause analysis and methods to be used for root cause analysis ?'"
# # "Give me the steps performed for the checking IQA file 'Are internal Audits happening as per the plan and finding tracked to closure?'"
# # "Give me the steps performed for the checking SoW file 'Is Contract / Letter Of Intent / Scope [Statement] Of Work available?'"
# # "Give me the steps performed for the checking SDP file 'Are resources(Human/Hardware/Software) required for the project identified? Is the project work environment established and maintained?'"
# # "Give me the steps performed for the checking DAR file 'Is DAR being performed as per the plan?'"
# # "Give me the steps performed for the checking DAR file 'Is DAR plan developed, criteria and approach to be taken for taking decision been identified and documented ?'"
# # "Give me the steps performed for the checking SDP file 'Are the Service Project related planning documents identified & prepared?'"
# # "Give me the steps performed for the checking CMP folder 'Is configuration management Plan available with details ?'"
# # "Give me the steps performed for the checking CMP folder 'Are development and release baseline of Internal and external work products, deliverables being planned and prepared'"