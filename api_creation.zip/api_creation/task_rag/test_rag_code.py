#from crewai_tools import tool
 
import os
import openai
from llama_index import SimpleDirectoryReader
from llama_index import Document
from llama_index import ServiceContext, set_global_service_context
from llama_index.llms import OpenAI
from llama_index.embeddings import OpenAIEmbedding
from llama_index.node_parser import (
    SentenceWindowNodeParser,
)
from llama_index import VectorStoreIndex
from llama_index.postprocessor import MetadataReplacementPostProcessor
 
api_key = "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"
openai.api_key = api_key
class Task_Tool():
#    @tool("task list based on review")
    def task_list(self,precise_reason: str) -> str:
        """precise_reason is a input and do the related operation as below suggested and gives tasks steps in return. """
       
        documents = SimpleDirectoryReader(r"C:\Users\MGupta\Desktop\HawkAI\Projects\Project\Modified\task_rag\Document").load_data()
        # document = Document(text=" ".join([doc.text for doc in documents]))
 
        # create the sentence window node parser w/ default settings
        node_parser = SentenceWindowNodeParser.from_defaults(
            window_size=10,
            window_metadata_key="window",
            original_text_metadata_key="original_text",
        )
 
        # base node parser is a sentence splitter
        # text_splitter = SentenceSplitter()
 
        llm = OpenAI(model="gpt-3.5-turbo", temperature=0)
        embed_model = OpenAIEmbedding()
        ctx = ServiceContext.from_defaults(
            llm=llm,
            embed_model=embed_model,
            node_parser=node_parser,
        )
 
        nodes = node_parser.get_nodes_from_documents(documents)
 
        sentence_index = VectorStoreIndex(nodes, service_context=ctx)
 
        # sentence_index.storage_context.persist(persist_dir="./storage_2")
 
        query_engine = sentence_index.as_query_engine(
            similarity_top_k=10,
            # the target key defaults to `window` to match the node_parser's default
            node_postprocessors=[
                MetadataReplacementPostProcessor(target_metadata_key="window")
            ],
        )
 
        def required_list_of_data(query):
            window_response = query_engine.query(query)
            return window_response
        query = str(precise_reason)
       
       
        query_3 = f'''   This context has steps for checking the SDP file is prsent or not inside Ralph_Lauren folder, below are the steps to be performed 
        Step-1: Search for the folder name SDP (function) 
        Step-2: Create a path for SDP Folder. 
        Step-3: Check for the existence of a folder named as specified within the root 
                folder path and check subdirectories. If found, return the path to the folder. If not, return "not found".
        Step-4: Check if any file exists in a folder or its subdirectories and return True if at least one file exists, otherwise False.
        Step-5: Check for the existence of .docx files in a folder and its subdirectories. Return 'Fully Implemented' if such a file exists, otherwise return 'Partially Implemented'.

        For the query given below I want correct and properly format output the format of the output should be in json format. 

query:{query}'''


        query_4 = f'''   This context has steps for checking the SoW file is prsent or not inside Ralph_Lauren folder and if present check it contains heading like 
        '‘Scope of work' is present or not, below are the steps to be performed 
          Step-1: Search for the folder name SoW (function) 
          Step-2: Create a path for SoW Folder. 
          Step-3: Check for the existence of a folder named as specified within the root folder path and check subdirectories. If found, return the path to the folder. If not, return "not found".
          Step-4: Check if any file exists in a folder or its subdirectories and return True if at least one file exists, otherwise False.
Step-5: Check for the existence of pdf files in a folder and its subdirectories.
Step-6: Check whether the file has heading name as ‘Scope of work’.
tep-7: Return 'Fully Implemented' if such a heading is present, otherwise return 'Partially Implemented'.


        For the query given below I want correct and properly format output the format of the output should be in json format. 

query:{query}'''
       

        query_5 = f'''   This context has steps for checking the SoW file is prsent or not inside Ralph_Lauren folder and if present check it contains heading like 
        '‘Scope of work' is present or not, below are the steps to be performed 
          Step-1: Search for the folder name RAID Register (function) 
          Step-2: Create a path for RAID Register Folder. 
          Step-3: Check for the existence of a folder named as specified within the root folder path and check subdirectories. If found, return the path to the folder. If not, return "not found".
          Step-4: Check if any file exists in a folder or its subdirectories and return True if at least one file exists, otherwise False.
Step-5: Check for the existence of .xlsx files in a folder and its subdirectories.
Step-6: Check if the file has data or not inside it in the sheet ‘Issues’
Step-7: Return 'Fully Implemented' if such a file has data, otherwise return 
'Partially Implemented'


        For the query given below I want correct and properly format output the format of the output should be in json format. 

query:{query}'''


        replace_or_repair = required_list_of_data(query_3)
        replace_or_repair2 = required_list_of_data(query_4)
        replace_or_repair3 = required_list_of_data(query_5)

        
        return  "task generated successfully : " +str(replace_or_repair3) 
        
    
    # Function logic here
 
tsk=Task_Tool()
#res = tsk.task_list("Check if 'SDP' named folder exist or not inside the Ralph_Lauren project if exist then check whether any file exists inside 'SDP' or not if file exist then check it is .docx file or not")
#res = tsk.task_list("check if 'SoW' named folder exist or not inside the Ralph_Lauren project if exist then check whether any file exists inside 'SoW' or not if the pdf file exist then go and read pdf file and then check is the file contains heading name 'Scope of Work' present or not.")
#res = tsk.task_list("Check if 'IQA Reports' named folder exist or not inside the Ralph_Lauren project if exist then check whether any file exists inside 'IQA Reports' or not and if file exist check whether it is a .xlsx file or not")
#res = tsk.task_list("Check if 'CAR' named folder exist or not inside the Ralph_Lauren project.")
#res = tsk.task_list("Check if 'Kick-off' named folder exist or not inside the Ralph_Lauren project if exist then check whether any file exists inside 'Kick-off' or not if file exist then check it is .pptx file or not")
#res = tsk.task_list("Check if 'DAR' named folder exist or not inside the Ralph_Lauren project if exist then check whether any file exists inside 'DAR' or not and if file exist check whether it is a .xlsx file or not")
# res = tsk.task_list("check if 'RAID Register' named folder exist or not inside the Ralph_Lauren if exist then check whether any file exists inside 'RAID Register' or not, if yes then check if it is in .xlsx format or not and then check the excel file with sheet name 'Issues' has data check it is open state or close")
#res = tsk.task_list("Check if 'RAID Register' named folder exist or not inside the Ralph_Lauren project if exist then check whether any file exists inside 'RAID Register' or not and if file exist check whether it is a .xlsx file, if it is .xlsx file then check if 'Risk Tracker' and 'Opportunity Tracker' sheets contain any data or not")
res = tsk.task_list("Give me the steps performed for the checking SDP file 'Are the Service Project related planning documents identified & prepared?'")
res = tsk.task_list("Give me the steps performed for the checking IQA file 'Are internal Audits happening as per the plan and finding tracked to closure?'")
res = tsk.task_list("Give me the steps performed for the checking CAR file 'Are causal analysis plan documented with selection of types of outcomes for Root cause analysis and methods to be used for root cause analysis ?'")
res = tsk.task_list("Give me the steps performed for the checking Kick-off file 'Is Project Kick-Off Meeting conducted with all the stakeholders and minutes documented? Is the Kick-off presentation available in the project repository? Are all the activities applicable for the project initiation been completed?'")
res = tsk.task_list("Give me the steps performed for the checking SoW file 'Is Contract / Letter Of Intent / Scope [Statement] Of Work available?'")
res = tsk.task_list("Give me the steps performed for the checking RAID Register file 'Are Issue Logs being maintained, updated and issues tracked to closure?")

print(res)


 
 



#  Step-1: Search for the folder name SDP (function) 
#  Step-2: Create a path for SDP Folder. 
#  Step-3: Check for the existence of a folder named as specified within the root 
# folder path and check subdirectories. If found, return the path to the folder. If 
# not, return "not found". Also print True or False accordingly.
#  Step-4: Check if any file exists in a folder or its subdirectories and return True if
# at least one file exists, otherwise False. Also print True or False accordingly.
#  Step-5: Check for the existence of .docx files in a folder and its subdirectories. 
# Return 'Fully Implemented' if such a file exists, otherwise return 'Partially 
# Implemented'.
#  Step-6: If returns 'Fully Implemented' print ‘SDP file exists in Ralph_Lauren 
# folder’ , for 'Partially Implemented' print ‘SDP file does not exists in Ralph_Lauren 
# folder’



 
 
    # Search for the folder name SDP, then create a path for SDP Folder.Check for the existence of
    #     a folder named as specified within the root folder path and check subdirectories.If found, return the path
    #     to the folder. If not, return "not found".Check if any file exists in a folder or its subdirectories and
    #     return True if at least one file exists, otherwise False.Check for the existence of .docx files in a folder
    #     and its subdirectories. Return 'Fully Implemented' if such a file exists, otherwise return 'Partially Implemented'.



# Search for the folder name SoW, then create a path for SoW Folder.Check for the existence of
#         a folder named as specified within the root folder path and check subdirectories.If found, return the path
#         to the folder. If not, return "not found".Check if any file exists in a folder or its subdirectories and
#         return True if at least one file exists, otherwise False.Check for the existence of pdf files in a folder
#         and its subdirectories. Return 'Fully Implemented' if pdf file contains text like 'Scope of Work', otherwise return 'Partially Implemented'.



    # Search for the folder name Kick-off, then create a path for Kick-off Folder.Check for the existence of
    #     a folder named as specified within the root folder path and check subdirectories.If found, return the path
    #     to the folder. If not, return "not found".Check if any file exists in a folder or its subdirectories and
    #     return True if at least one file exists, otherwise False.Check for the existence of .pptx files in a folder
    #     and its subdirectories. Return 'Fully Implemented', otherwise return 'Partially Implemented'.  



    # Search for the folder name RAID Register, then create a path for RAID Register Folder.Check for the existence of
    #     a folder named as specified within the root folder path and check subdirectories.If found, return the path
    #     to the folder. If not, return "Folder not found".Check if any file exists in a folder or its subdirectories and
    #     return True if at least one file exists, otherwise False. Check for the existence of .xlsx files in a folder.
    #     Return 'Fully Implemented' if .xlsx file contains data in the sheet named 'Issues' , otherwise return 'Partially Implemented'.



    # Example:
    #     Folder named SDP prsent: True/False,
    #     Folder contain file: True/False,
    #     Folder contain .docx file: True/False,
    #     Implementation Status: 'Fully Implemented'/Partially Implemented,
    #     Validate: 'Yes/No SDP file is present/not present in Ralph_Lauren'