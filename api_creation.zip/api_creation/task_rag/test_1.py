from llama_index import ServiceContext, set_global_service_context
from llama_index.llms import OpenAI
from llama_index import VectorStoreIndex
from llama_index import (
    StorageContext,
    load_index_from_storage,
)
from llama_index.llms import WatsonX
from llama_index.embeddings import HuggingFaceEmbedding
from ibm_watson_machine_learning.foundation_models.utils.enums import ModelTypes
from ibm_watson_machine_learning.metanames import GenTextParamsMetaNames as GenParams
from ibm_watson_machine_learning.foundation_models.utils.enums import DecodingMethods
from flask import Flask, jsonify, request, render_template
from waitress import serve
from llama_index.embeddings import OpenAIEmbedding
from flask_cors import CORS

from llama_index.postprocessor import MetadataReplacementPostProcessor
import openai

api_key = "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"

openai.api_key = api_key
# rebuild storage context
ps_directory=r'C:\\Users\\ShPandey\\Downloads\\DemoGptFoundary\\Storage\\cushman_ks\\'
storage_context = StorageContext.from_defaults(persist_dir=ps_directory)
# load index
index = load_index_from_storage(storage_context)


query_engine = index.as_query_engine(
    similarity_top_k=4,
        node_postprocessors=[
        MetadataReplacementPostProcessor(target_metadata_key="window")
    ],
)

# def required_result_from_docs(query):
#     window_response = query_engine.query(query)
#     return window_response.response


app = Flask(__name__)
CORS(app)

@app.route('/rag_chat', methods=['POST'])
def get_record():
    def process_query(query):
        if "building owner" in query.lower():
            query_1 = '''Landlord can be referred to as building owner, if asked who is the building owner, the answer should
                    be the name of the lanlord.'''
        elif "building location" in query.lower() or "building address" in query.lower() or "premise" in query.lower():
            query_1 = f'''for the question which is given by query which is delimited by triple backticks if address or location of a premise is asked in the question, the answer should be as defined in
                    the following examples - 
                    example 1 = costco wholse sale located at 8055 Churchill Way, Dallas, TX 75251.
                    example 2 = park centrallocated at 12411 N Central Expy, Dallas, TX 75243.
                    query:{query}'''
        elif "tenant" in query.lower():
            query_1 = f'''If the question does not asks about addresses or building owner then Give the 
                    information present in the agreement which is relevant to the question which is defined by 
                    query_1 which is delimited by triple backticks.
                    if address or location of a premise is asked in the question which is defined by 
                    query_1 which is delimited by triple backticks, the answer should be as defined in
                    the following examples - 
                    example 1 = costco wholesale located at 8055 Churchill Way, Dallas, TX 75251.
                    example 2 = park central located at 12411 N Central Expy, Dallas, TX 75243.
                    Landlord can be referred to as building owner, if asked who is the building owner, the answer should
                    be the name of the lanlord.
                    The base rent schedule is also present in the context, if asked then provide the correct explaination
                    of how the base rent should be paid.
                    The name of Tenant is present in the context, when asked provide the correct name as answer.
                    query_1:{query}'''
        else:
            query_1 = query
        return query_1
    try:
        json_data = request.json
        query = json_data.get('message', '')
        
        valid_greetings = ["hi", "hello", "hey", "morning", "afternoon", "evening"]
        
        if query.lower() in valid_greetings:
            return jsonify({"result": "Hello, welcome to Cushman & Wakefield! How can I assist you"})
        else:
            query_1 = process_query(query)
            result=query_engine.query(query_1)
            # if detected_lan=='en':
            return jsonify({"result": result.response})
            # else:
            #     return jsonify({"result": translate_output(result,detected_lan)})
    except Exception as e:
        error_message = f"Error occurred: {str(e)}"
        print(error_message)
        return jsonify({"error": error_message}), 500  # Return a 500 Internal Server Error status code

if __name__ == '__main__':
    serve(app, port="9003")

# query = 'tenant representative firm'

# if "location" or "address" or "building owner" in query:
#     prompt = f'''Give the information present in the agreement which is relevant to the question which
#     is defined by query_1 which is delimited by triple backticks.
#     Other than normal questions if address or location of a premise is asked in the question, the answer should be as defined in
#     the following examples - 
#     example 1 = costco wholse sale located at 8055 Churchill Way, Dallas, TX 75251.
#     example 2 = park centrallocated at 12411 N Central Expy, Dallas, TX 75243.
#     Landlord can be referred to as building owner, if asked who is the building owner, the answer should
#     be the name of the lanlord.
#     query_1:```{query}```
#     '''
#     window_response = query_engine.query(prompt)
#     # print(required_result_of_data(prompt))
#     print(window_response)
# elif "location" or "address" or "building owner" not in query:
#     prompt = f'''Give the information present in the agreement which is relevant to the question which
#     is defined by query_1 which is delimited by triple backticks.
#     query_1:```{query}```
#     '''
#     window_response = query_engine.query(query)
#     # print(required_result_of_data(prompt))
#     print(window_response)
# prompt = f'''If the question does not asks about addresses or building owner then Give the 
# information present in the agreement which is relevant to the question which is defined by 
# query_1 which is delimited by triple backticks.
# if address or location of a premise is asked in the question which is defined by 
# query_1 which is delimited by triple backticks, the answer should be as defined in
# the following examples - 
# example 1 = costco wholesale located at 8055 Churchill Way, Dallas, TX 75251.
# example 2 = park central located at 12411 N Central Expy, Dallas, TX 75243.
# Landlord can be referred to as building owner, if asked who is the building owner, the answer should
# be the name of the lanlord.
# The base rent schedule is also present in the context, if asked then provide the correct explaination
# of how the base rent should be paid.
# The name of Tenant is present in the context, when asked provide the correct name as answer.
# query_1:```{query}```
# '''
# window_response = query_engine.query(query_1)
# print(window_response) 
