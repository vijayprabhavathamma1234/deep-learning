#from crewai_tools import tool
 
import os
import openai
from llama_index import SimpleDirectoryReader
from llama_index import Document
from llama_index import ServiceContext, set_global_service_context
from llama_index.llms import OpenAI
from llama_index.embeddings import OpenAIEmbedding
from llama_index.node_parser import (
    SentenceWindowNodeParser,
)
from llama_index import VectorStoreIndex
from llama_index.postprocessor import MetadataReplacementPostProcessor
 
api_key = "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"
openai.api_key = api_key
class Task_Tool():
#    @tool("task list based on review")
    def task_list(self,precise_reason: str) -> str:
        """precise_reason is a input and do the related operation as below suggested and gives tasks steps in return. """
       
        documents = SimpleDirectoryReader(r"C:\Users\vgarlapati\Downloads\RL_Project1(old)\RL_Project1\Ralph_Lauren_v2\api_creation\task_rag\Document").load_data()
        # document = Document(text=" ".join([doc.text for doc in documents]))
 
        # create the sentence window node parser w/ default settings
        node_parser = SentenceWindowNodeParser.from_defaults(
            window_size=10,
            window_metadata_key="window",
            original_text_metadata_key="original_text",
        )
 
        # base node parser is a sentence splitter
        # text_splitter = SentenceSplitter()
 
        llm = OpenAI(model="gpt-3.5-turbo", temperature=0)
        embed_model = OpenAIEmbedding()
        ctx = ServiceContext.from_defaults(
            llm=llm,
            embed_model=embed_model,
            node_parser=node_parser,
        )
 
        nodes = node_parser.get_nodes_from_documents(documents)
 
        sentence_index = VectorStoreIndex(nodes, service_context=ctx)
 
        # sentence_index.storage_context.persist(persist_dir="./storage_2")
 
        query_engine = sentence_index.as_query_engine(
            similarity_top_k=10,
            # the target key defaults to `window` to match the node_parser's default
            node_postprocessors=[
                MetadataReplacementPostProcessor(target_metadata_key="window")
            ],
        )
 
        def required_list_of_data(query):
            window_response = query_engine.query(query)
            return window_response
        query = str(precise_reason)
       
       


        query_6 = f''' This context has steps for performing some operations and give end result as 'Fully Implemented' if end result is True else  'Partially Implemenetd '   with proper valid reason after solving the case.
      below is the example of one case.
       Example:  
        "check if 'ask_hr' named folder exist or not inside the Ralph_Lauren project if exist then check whether any file exists inside 'ask_hr' or not if the pdf file 
        exist then go and read pdf file and then check is the file contains 'Human Resources' in it or not final if condition satisfies return fully implemnetd in output else partially implemented."

     For the query I want correct and properly format output the format of the output should be in json format. 
query:{query}'''
        
#         query_7 = f''' "This guide outlines the steps for performing certain operations and determines the end result as 'Fully Implemented' if it evaluates to True; otherwise, it's marked as 'Partially Implemented' with a valid reason after resolving the case. Below is an example case:

# Example:
# Check if a folder named 'SoW' exists within the Ralph_Lauren project. If it exists, print 'Yes'; otherwise, print 'No' in the output. Then, check if any files exist inside 'SoW'.
#  If they do, print 'Yes'; otherwise, print 'No' in the output. Next, if a PDF file exists, print 'Yes'; otherwise, print 'No' in the output. Proceed to read the PDF file and check if it contains 'Scope of Work'. 
# If it does, print 'Yes'; otherwise, print 'No' in the output. Finally, if all conditions are satisfied, return 'Fully Implemented'; otherwise, return 'Partially Implemented'."
# query:{query}'''

# Split the output whenever '.' is present and take the spilted setence as new element of list Give the output into list of string format.
        replace_or_repair3 = required_list_of_data(query_6)
        # print("Query Response:", replace_or_repair3)

        
        return  str(replace_or_repair3) 
        
    
    # Function logic here
 
tsk=Task_Tool()
#res = tsk.task_list("Check if 'SDP' named folder exist or not inside the Ralph_Lauren project if exist then check whether any file exists inside 'SDP' or not if file exist then check it is .docx file or not")
#res = tsk.task_list("check if 'SoW' named folder exist or not inside the Ralph_Lauren project if exist then check whether any file exists inside 'SoW' or not if the pdf file exist then go and read pdf file and then check is the file contains heading name 'Scope of Work' present or not.")
#res = tsk.task_list("Check if 'IQA Reports' named folder exist or not inside the Ralph_Lauren project if exist then check whether any file exists inside 'IQA Reports' or not and if file exist check whether it is a .xlsx file or not")
#res = tsk.task_list("Check if 'CAR' named folder exist or not inside the Ralph_Lauren project.")
#res = tsk.task_list("Check if 'Kick-off' named folder exist or not inside the Ralph_Lauren project if exist then check whether any file exists inside 'Kick-off' or not if file exist then check it is .pptx file or not")
#res = tsk.task_list("Check if 'DAR' named folder exist or not inside the Ralph_Lauren project if exist then check whether any file exists inside 'DAR' or not and if file exist check whether it is a .xlsx file or not")
# res = tsk.task_list("check if 'RAID Register' named folder exist or not inside the Ralph_Lauren if exist then check whether any file exists inside 'RAID Register' or not, if yes then check if it is in .xlsx format or not and then check the excel file with sheet name 'Issues' has data check it is open state or close")
#res = tsk.task_list("Check if 'RAID Register' named folder exist or not inside the Ralph_Lauren project if exist then check whether any file exists inside 'RAID Register' or not and if file exist check whether it is a .xlsx file, if it is .xlsx file then check if 'Risk Tracker' and 'Opportunity Tracker' sheets contain any data or not")
# res = tsk.task_list("Give me the steps performed for the checking SDP file 'Are the Service Project related planning documents identified & prepared?'")
# res = tsk.task_list("Give me the steps performed for the checking IQA file 'Are internal Audits happening as per the plan and finding tracked to closure?'")
# res = tsk.task_list("Give me the steps performed for the checking CAR file 'Are causal analysis plan documented with selection of types of outcomes for Root cause analysis and methods to be used for root cause analysis ?'")
# res = tsk.task_list("Give me the steps performed for the checking Kick-off file 'Is Project Kick-Off Meeting conducted with all the stakeholders and minutes documented? Is the Kick-off presentation available in the project repository? Are all the activities applicable for the project initiation been completed?'")
# res = tsk.task_list("Give me the steps performed for the checking SoW file 'Is Contract / Letter Of Intent / Scope [Statement] Of Work available?'")

def give_task_list(query):
    res = tsk.task_list(query)
    # print("Final Result:", res)
    return res

# query="Give me the steps performed for the checking RAID Register file 'Are Issue Logs being maintained, updated and issues tracked to closure?"
# res = give_task_list(query)
# print(res) 

# ,get_sheet_names_tool, check_sheet_for_text_tool




# This context outlines steps for operations, marking the result as 'Fully Implemented' if successful, else 'Partially Implemented' with a valid reason.
#        Example:  
#         "check if 'SoW' named folder exist or not inside the Ralph_Lauren project if exist then check whether any file exists inside 'SoW' or not if the pdf file 
#         exist then go and read pdf file and then check is the file contains 'Scope of Work' in it or not final if condition satisfies return fully implemnetd in output else partially implemented."

#      For the query I want correct and properly format output the format of the output should be in json format. 