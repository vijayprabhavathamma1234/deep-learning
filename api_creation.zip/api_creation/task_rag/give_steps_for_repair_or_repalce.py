import os
import openai
from llama_index import SimpleDirectoryReader
from llama_index import Document
from llama_index import ServiceContext, set_global_service_context
from llama_index.llms import OpenAI
from llama_index.embeddings import OpenAIEmbedding
from llama_index.node_parser import (
    SentenceWindowNodeParser,
)
from llama_index import VectorStoreIndex
from llama_index.postprocessor import MetadataReplacementPostProcessor

api_key = "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"
openai.api_key = api_key

def steps_repair_rplace(user_query):
    documents = SimpleDirectoryReader(r"C:\Users\VGarlapati\Downloads\john deere\task_rag\folder_4").load_data()
    # document = Document(text=" ".join([doc.text for doc in documents]))

    # create the sentence window node parser w/ default settings
    node_parser = SentenceWindowNodeParser.from_defaults(
        window_size=10,
        window_metadata_key="window",
        original_text_metadata_key="original_text",
    )

    # base node parser is a sentence splitter
    # text_splitter = SentenceSplitter()

    llm = OpenAI(model="gpt-3.5-turbo", temperature=0)
    embed_model = OpenAIEmbedding()
    ctx = ServiceContext.from_defaults(
        llm=llm,
        embed_model=embed_model,
        node_parser=node_parser,
    )

    nodes = node_parser.get_nodes_from_documents(documents)

    sentence_index = VectorStoreIndex(nodes, service_context=ctx)

    # sentence_index.storage_context.persist(persist_dir="./storage_2")

    query_engine = sentence_index.as_query_engine(
        similarity_top_k=10,
        # the target key defaults to `window` to match the node_parser's default
        node_postprocessors=[
            MetadataReplacementPostProcessor(target_metadata_key="window")
        ],
    )

    def required_list_of_data(query):
        window_response = query_engine.query(query)
        return window_response
    query = str(user_query)
    
    
    query_3 = f'''for the question which is given by query which is delimited by triple backticks, analyze
              whether the sentiment of the query is positive or negative.If the sentiment of the query is
              positive then the answers should be "Thanks for the appreciation" and the answer should also
              include steps to be performed for appreciation with proper format as present in the context.Else if the sentiment of the query is negative and
              the product needs a replacement the answer should be- "The product needs a replacement" and the answer should also include the steps to be
              performed for the replacement of the product.Else if the sentiment of the query is negative and
              If the product needs a repair the answer should be- "The product needs a repair" and the
              answer should also include steps to be performed for the repair of the product.Else If the sentiment of the query is negative and
              the review in the query contains refund or return in it then the answer should include the
              steps to be performed for the return or refund of the product. The steps to be performed for appreciation
              ,replacement,repair,return or refund should be in proper format.
              query:{query}'''
    
    replace_or_repair = required_list_of_data(query_3)
    return str(replace_or_repair)
