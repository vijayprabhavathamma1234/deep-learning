import requests
import json

def make_post_request(url, payload):
    headers = {'Content-Type': 'application/json'}

    try:
        response = requests.post(url, data=json.dumps(payload), headers=headers)
        # response.raise_for_status()  # Raise an error for bad responses (4xx and 5xx)
        return response.text  # Return the JSON response if available
    except requests.exceptions.RequestException as e:
        print(f"Error making POST request: {e}")
        return None

# Example usage with the provided URL and payload
url = "https://prod-18.centralindia.logic.azure.com:443/workflows/2aa17a6a1a8844f081798c75d4afd476/triggers/manual/paths/invoke?api-version=2016-06-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=tXrlX4UW9vf8rQEcA5DEAw4Y1TCNWQUH51PybefRkOc"
payload = {
    "refund_order_id": "1",
    "order_id": "2",
    "user_id": "3",
    "amount": 35000.00
}

response = make_post_request(url, payload)
print(response)
