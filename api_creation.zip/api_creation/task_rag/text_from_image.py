import os
import fitz  # PyMuPDF
from pdf2image import convert_from_path
import easyocr
import numpy as np
 
# Function to extract text from a PDF file using EasyOCR
def extract_text_from_pdf(pdf_path):
    try:
        # Check if the PDF file exists
        if not os.path.isfile(pdf_path):
            return "Error: PDF file not found."
 
        # Initialize EasyOCR reader for English language
        reader = easyocr.Reader(['en'])
 
        # Convert PDF pages to images
        images = convert_from_path(pdf_path)
        print("Number of pages:", len(images))
 
        # Initialize variable to store extracted text
        extracted_text = ""
 
        # Iterate through each image (page) and perform OCR
        for i, image in enumerate(images):
            # Convert PIL image to NumPy array
            image_np = np.array(image)
 
            # Perform OCR on the image
            result = reader.readtext(image_np)
 
            # Append the extracted text along with page number
            extracted_text += f"Page {i + 1} text:\n--------------------\n"
            for text_result in result:
                extracted_text += text_result[1] + "\n"
 
        # Extract text directly from PDF pages using PyMuPDF
        with fitz.open(pdf_path) as doc:
            for page_num in range(len(doc)):
                page = doc.load_page(page_num)
                page_text = page.get_text()
                if page_text:
                    extracted_text += page_text.strip() + "\n\n"
 
        return extracted_text.strip()
 
    except Exception as e:
        return f"Error: Unable to extract text from PDF: {e}"
 
# Main workflow
if __name__ == "__main__":
    # Specify the PDF file path
    pdf_path = r"C:\Users\ShPandey\Downloads\cush_w\676-120 John Vermillion Second Amendment_rotated (1).pdf"  # Replace with your actual path
 
    # Extract text from the PDF using EasyOCR
    extracted_text = extract_text_from_pdf(pdf_path)
    print(extracted_text)
