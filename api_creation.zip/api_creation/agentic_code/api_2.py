# from flask import Flask, request, jsonify
# from flask_cors import CORS
 
# from task_rag.task_api import give_task_list as give_list
# from agentic_code.quality_agent import *
# from flask_socketio import SocketIO
 
# app = Flask(__name__)
# CORS(app)
# socketio = SocketIO(app, cors_allowed_origins="http://localhost:3000")
 
# logs = []  # List to store logs
 
# @app.route('/call_function', methods=['POST'])
# def call_function():
#     query = request.json.get('query')
#     res = give_list(query)
#     log_entry = f"call_function: {res}"
#     socketio.emit('log', log_entry)  # Emit log to WebSocket clients
#     return jsonify(res)
 
# @app.route('/task_execute', methods=['POST'])
# def task_execute():
   
#     query = request.json.get('query')
#     print(query)
#     res = user_prompt(query)
#     # Emit log to WebSocket clients
#     log_entry = f"call_function: {query}"
#     socketio.emit('log', log_entry)
#     socketio.emit('log', ' ')
#     log_entry1 = f"compliance: {res}"
#     socketio.emit('log', log_entry1)
#     return jsonify(result=res)
 
# @app.route('/get_logs')
# def get_logs():
#     return jsonify(logs)
 
# if __name__ == '__main__':
#     socketio.run(app)






#############################################################################################################################################################################  

import json
from typing import Sequence, List

from llama_index.llms import OpenAI, ChatMessage
from llama_index.tools import BaseTool, FunctionTool


import nest_asyncio
import os

from llama_index.agent import OpenAIAgent
from llama_index.llms import OpenAI

import csv
import os
import uuid
import requests
import zipfile
import xml.etree.ElementTree as ET

#from check_review import desc_compare

os.environ["OPENAI_API_KEY"] = "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"
nest_asyncio.apply()


import os
import pdfplumber
import pandas as pd



def check_folder_existence(folder_name: str) -> str:
    """
    Check whether a folder with the given name exists inside the root folder path and its subdirectories.
    Returns the path of the folder if found, otherwise returns "not found".
    """
    
    root_name = "Ralph_Lauren_v2"
    default_path = r'C:\Users\NAnukula\Downloads\RL_Project1'
    root_folder_path = os.path.join(default_path, root_name)
    
    # Walk through the directory tree starting from the root folder
    for root, dirs, files in os.walk(root_folder_path):
        if folder_name in dirs:
            return os.path.join(root, folder_name)
    return "Folder '{}' not found inside {} and its subdirectories.".format(folder_name, root_folder_path)


check_folder_existence_tool = FunctionTool.from_defaults(fn=check_folder_existence)


def check_file_existence(folder_path: str) -> bool:
    """
    Check if any file exists inside the given folder or its subdirectories.
    Returns True if at least one file exists, otherwise False.
    """
    # Walk through the directory tree starting from the given folder
    for root, dirs, files in os.walk(folder_path):
        if files:
            return True  # At least one file exists
    return False  # No file exists


check_file_existence_tool =FunctionTool.from_defaults(fn=check_file_existence)


#############################################################  IQA Report  ########################################################################

def check_xlsx_file_existence(folder_path: str) -> str:
    """
    Check if a .xlsx file exists inside the given folder or its subdirectories.
    Returns 'Fully Implemented' if an .xlsx file exists, otherwise 'Partially Implemented'.
    """
    # Walk through the directory tree starting from the given folder
    for root, dirs, files in os.walk(folder_path):
        for file in files:
            if file.endswith('.xlsx'):
                return True
    return False


check_xlsx_file_existence_tool = FunctionTool.from_defaults(fn=check_xlsx_file_existence)


#################################################  Kick-off ppt  ##############################################################


def check_pptx_file_existence(folder_path: str) -> str:
    """
    Check if a .pptx file exists inside the given folder or its subdirectories.
    Returns 'Fully Implemented' if an .pptx file exists, otherwise 'Partially Implemented'.
    """
    
    for root, dirs, files in os.walk(folder_path):
        for file in files:
            if file.endswith('.pptx'):
                return True
    return False


check_pptx_file_existence_tool = FunctionTool.from_defaults(fn=check_pptx_file_existence)



##################################################### sow headings  ################################################################# 

def read_pdf(folder_path: str) -> bool:
    """
    Check if a .docx file exists inside the given folder or its subdirectories.
    Returns True if a .docx file exists, otherwise False.
    """
    # Walk through the directory tree starting from the given folder
    for root, dirs, files in os.walk(folder_path):
        for file in files:
            if file.endswith('.pdf'):
                return True
    return False

read_pdf_tool  = FunctionTool.from_defaults(fn=read_pdf)





def check_sow_heading(folder_path: str) -> bool:
    """
    Check if the 'Scope of Work' heading is present in any PDF file inside the given folder or its subdirectories.
    Returns True if the heading is found, otherwise False.
    """
    # Walk through the directory tree starting from the given folder
    for root, dirs, files in os.walk(folder_path):
        for file_name in files:
            if file_name.endswith('.pdf'):
                file_path = os.path.join(root, file_name)
                with pdfplumber.open(file_path) as pdf:
                    for page in pdf.pages:
                        text = page.extract_text()
                        if 'Scope of Work' in text:
                            return True
    return False

check_sow_heading_tool  = FunctionTool.from_defaults(fn=check_sow_heading)




################################################  sdp present ####################################



def check_sdp_existence(folder_path: str) -> bool:
    """
    Check if a .docx file exists inside the given folder or its subdirectories.
    Returns True if a .docx file exists, otherwise False.
    """
    # Walk through the directory tree starting from the given folder
    for root, dirs, files in os.walk(folder_path):
        for file in files:
            if file.endswith('.docx'):
                return True
    return False

check_sdp_existence_tool  = FunctionTool.from_defaults(fn=check_sdp_existence)


import os
from docx import Document

def check_sdp_heading(folder_path: str) -> bool:
    """
    Check if the 'Hardware, Software and Network Resources' heading is present in any DOCX file inside the given folder or its subdirectories.
    Returns True if the heading is found, otherwise False.
    """
    # Walk through the directory tree starting from the given folder
    for root, dirs, files in os.walk(folder_path):
        for file_name in files:
            if file_name.endswith('.docx'):
                file_path = os.path.join(root, file_name)
                doc = Document(file_path)
                for paragraph in doc.paragraphs:
                    if 'Hardware, Software and Network Resources' in paragraph.text:
                        return True
    return False

check_sdp_heading_tool = FunctionTool.from_defaults(fn=check_sdp_heading)


##########################################  risk_opportunity_maintained  #################################



# def check_risk_opportunity_maintained(folder_path: str) -> bool:
#     """
#     Check if 'Risk Tracker' and 'Opportunity Tracker' sheets contain any data in the given Excel file.
#     Returns True indicating whether each sheet contains data, otherwise False.
#     """
#     risk_data_exists = False
#     opportunity_data_exists = False
    
#     # Check if the Excel file exists
#     excel_files = [file for file in os.listdir(folder_path) if file.endswith('.xlsx')]
#     if excel_files:
#         for file in excel_files:
#             excel_path = os.path.join(folder_path, file)
#             try:
#                 # Read Excel file
#                 xl = pd.ExcelFile(excel_path)
#                 if 'Risk Tracker' in xl.sheet_names:
#                     risk_df = xl.parse('Risk Tracker')
#                     if not risk_df.empty:
#                         risk_data_exists = True
#                 if 'Opportunity Tracker' in xl.sheet_names:
#                     opportunity_df = xl.parse('Opportunity Tracker')
#                     if not opportunity_df.empty:
#                         opportunity_data_exists = True
#             except Exception as e:
#                 print(f"Error reading {file}: {e}")
    
#     if risk_data_exists and opportunity_data_exists == True:
#         return True
#     else:
#         return False



# check_risk_opportunity_maintained_tool = FunctionTool.from_defaults(fn=check_risk_opportunity_maintained)





####################################   check_raid_issue   ##################################################



# def check_raid_issue(folder_path: str) -> bool:
#     """
#     Check if 'Issues' sheets contain any data in the given Excel file.
#     Returns True indicating whether each sheet contains data check it is open state or close, otherwise False.
#     """
#     issues_data_exists = False
   
#     # Check if the Excel file exists
#     excel_files = [file for file in os.listdir(folder_path) if file.endswith('.xlsx')]
#     if excel_files:
#         for file in excel_files:
#             excel_path = os.path.join(folder_path, file)
#             try:
#                 # Read Excel file
#                 xl = pd.ExcelFile(excel_path)
#                 if 'Issues' in xl.sheet_names:
#                     issues_data_exists = xl.parse('Issues')
#                     if not issues_data_exists.empty:
#                         issues_data_exists = True
#             except Exception as e:
#                 print(f"Error reading {file}: {e}")
   
#     if issues_data_exists == True:
#         return True 
#     else:
#         return False
 
 
# check_raid_issue_tool = FunctionTool.from_defaults(fn=check_raid_issue)






#####################################  dar analysis  #############################






def get_sheet_names(folder_path: str) -> list:
    """
    Returns a list of sheet names from the first found .xlsx file within the given folder or its subdirectories.
    """
    try:
        sheet_names = []
        
        # Walk through the directory tree starting from the given folder
        for root, dirs, files in os.walk(folder_path):
            for file_name in files:
                if file_name.endswith('.xlsx'):
                    excel_file = os.path.join(root, file_name)
                    # Attempt to read the Excel file
                    try:
                        df = pd.read_excel(excel_file, sheet_name=None)
                        sheet_names.extend(df.keys())
                    except Exception as e:
                        print(f"Error occurred while reading Excel file '{excel_file}': {e}")
                        continue
                    break  # Stop after reading the first Excel file
            if sheet_names:
                break

        return sheet_names
        
    except Exception as e:
        print(f"Error occurred while processing folder '{folder_path}': {e}")
        return []


get_sheet_names_tool = FunctionTool.from_defaults(fn=get_sheet_names)



def check_sheet_for_text(folder_path: str) -> str:
    """
    Checks if the specified text is present in any of the sheets in the first found .xlsx file within the given folder or its subdirectories.
    Returns 'Fully Implemented' if found, otherwise 'Partially Implemented'.
    """
    try:
        # Define the text to search for
        target_text = 'GRID ANALYSIS'
        
        # Walk through the directory tree starting from the given folder
        for root, dirs, files in os.walk(folder_path):
            for file_name in files:
                if file_name.endswith('.xlsx'):
                    excel_file = os.path.join(root, file_name)
                    # Attempt to read the Excel file
                    try:
                        df = pd.read_excel(excel_file, sheet_name=None)
                    except Exception as e:
                        print(f"Error occurred while reading Excel file '{excel_file}': {e}")
                        continue

                    # Check each sheet for the target text
                    for sheet_name, sheet_df in df.items():
                        if any(sheet_df.apply(lambda row: target_text in ' '.join(map(str, row)), axis=1)):
                            return 'Fully Implemented'
        return 'Partially Implemented'
        
    except Exception as e:
        print(f"Error occurred while processing folder '{folder_path}': {e}")
        return 'Partially Implemented'



check_sheet_for_text_tool = FunctionTool.from_defaults(fn=check_sheet_for_text)














# def check_raid_issue(folder_path: str) -> bool:
#     """
#     Check if 'Issues' sheets has a column name as status which has value filled as close or close in the given Excel file.
#     Returns True if the values present are either closed or close, otherwise False.
#     """
#     issues_data_exists = False
   
#     # Check if the Excel file exists
#     excel_files = [file for file in os.listdir(folder_path) if file.endswith('.xlsx')]
#     if excel_files:
#         for file in excel_files:
#             excel_path = os.path.join(folder_path, file)
#             try:
#                 # Read Excel file and skip the first 3 rows
#                 xl = pd.read_excel(excel_path, sheet_name='Issues', skiprows=3)
#                 if not xl.empty:
#                     issues_data_exists = True
#                     # Display column names
#                     print(f"Column names in '{file}' Issues sheet:\n{list(xl.columns)}")
#                     # Check if 'status' column has all values filled as "closed" or "close"
#                     if xl['Status'].isin(['closed', 'close']).all():
#                         print("Fully implemented")
#                     else:
#                         print("Partially implemented")
#             except Exception as e:
#                 print(f"Error reading '{file}' or extracting data from 'Issues' sheet: {e}")
   
#     return issues_data_exists

# check_raid_issue_tool = FunctionTool.from_defaults(fn=check_raid_issue)




    # Check if 'Risk Tracker' and 'Opportunity Tracker' sheets contain any data in the given Excel file.
    # Returns True indicating whether each sheet contains data, otherwise False.





def check_risk_opportunity_maintained(folder_path: str) -> bool:
    """
    Check if 'Risk Tracker' sheet has 'Target Date' and 'Actual Date' columns with date format and 'Status' column with values as 'closed' or 'close'.
    Print column names and return True if conditions are met, otherwise False.
    """
    risk_data_exists = False
    target_actual_date_valid = False
    status_valid = False
    
    # Check if the Excel file exists
    excel_files = [file for file in os.listdir(folder_path) if file.endswith('.xlsx')]
    if excel_files:
        for file in excel_files:
            excel_path = os.path.join(folder_path, file)
            try:
                # Read Excel file and skip the first 3 rows
                risk_df = pd.read_excel(excel_path, sheet_name='Risk Tracker', skiprows=3)
                if not risk_df.empty:
                    risk_data_exists = True
                    
                    # Check 'Target Date' and 'Actual Date' columns for date format
                    date_cols = ['Target Date', 'Actual Date']
                    if all(risk_df[col].dtype == 'datetime64[ns]' for col in date_cols):
                        target_actual_date_valid = True
                    else:
                        print("Error: 'Target Date' and 'Actual Date' columns should be in date format.")
                    
                    # Check 'Status' column for values 'closed' or 'close'
                    if risk_df['Status'].isin(['closed', 'close']).all():
                        status_valid = True

                    elif risk_df['Status'].isin(['open', 'opened', None]).all():
                        status_valid = False
                    else:
                        print("Error: 'Status' column should have values 'closed' or 'close'.")
                    
            except Exception as e:
                print(f"Error reading {file}: {e}")
    
    if risk_data_exists and target_actual_date_valid and status_valid:
        print("Fully Implemented")
        return True
    else:
        print("Partially Implemented")
        return False


check_risk_opportunity_maintained_tool = FunctionTool.from_defaults(fn=check_risk_opportunity_maintained)










def check_raid_issue(folder_path: str) -> bool:
    """
    Check if 'Issues' sheets have a column named 'Status' with values "closed" or "close" in the given Excel file.
    If 'S. No.' column has data, check if 'Status' column has values "closed" or "close", else "open" or "opened" or null values.
    Print "Fully Implemented" if conditions are met, otherwise "Partially Implemented".
    """
    issues_data_exists = False
   
    # Check if the Excel file exists
    excel_files = [file for file in os.listdir(folder_path) if file.endswith('.xlsx')]
    if excel_files:
        for file in excel_files:
            excel_path = os.path.join(folder_path, file)
            try:
                # Read Excel file and skip the first 3 rows
                xl = pd.read_excel(excel_path, sheet_name='Issues', skiprows=3)
                if not xl.empty:
                    issues_data_exists = True
                    # Display column names
                    print(f"Column names in '{file}' Issues sheet:\n{list(xl.columns)}")
                    # Check if 'S. No.' column has data
                    if 'S. No.' in xl.columns and not xl['S. No.'].isnull().all():
                        # Check if 'Status' column has all values filled as "closed" or "close"
                        if xl['Status'].isin(['closed', 'close']).all():
                            print("Fully implemented")
                        elif xl['Status'].isin(['open', 'opened', None]).any():
                            print("Partially implemented")
                        else:
                            print("Status column has unknown values")
                    else:
                        print("S. No. column is empty")
            except Exception as e:
                print(f"Error reading '{file}' or extracting data from 'Issues' sheet: {e}")
 
check_raid_issue_tool = FunctionTool.from_defaults(fn=check_raid_issue)




def check_raid_closure(folder_path: str) -> bool:
    """
    Check if 'Revision History' sheets has a column names and display the coulmn names present in the sheet.
    And check if the data below the column names is not null.
    Returns True if the values present are not null, otherwise False.
    """
    closure_data_exists = False
   
# Check if the Excel file exists
    excel_files = [file for file in os.listdir(folder_path) if file.endswith('.xlsx')]
    if excel_files:
        for file in excel_files:
            excel_path = os.path.join(folder_path, file)
            try:
                # Read Excel file and skip the first 3 rows
                xl = pd.read_excel(excel_path, sheet_name='Revision History', skiprows=3)
                if not xl.empty:
                    closure_data_exists = True
                    # Display column names
                    print(f"Column names in '{file}' Revision History sheet:\n{list(xl.columns)}")
            except Exception as e:
                print(f"Error reading '{file}' or extracting data from 'Revision History' sheet: {e}")
   
   
    return closure_data_exists

check_raid_closure_tool = FunctionTool.from_defaults(fn=check_raid_closure)





#####################################  ESR TC #########################################




# def check_skill_record_tc(folder_path: str) -> bool:
#     """
#      check whether any file exists inside 'ESR' or not if the .xlsx file exist then go and read 
#    .xlsx file and then go and check if the sheet named 'Training Calendar' is preent or not
#      if present then go inside 'Training Calendar' sheet name and check if 'Status' named column 
#    contains text like 'Completed' or not
#     """
#     # Check if any Excel file exists
#     excel_files = [file for file in os.listdir(folder_path) if file.endswith('.xlsx')]
#     if excel_files:
#         for file in excel_files:
#             excel_path = os.path.join(folder_path, file)
#             try:
#                 # Read Excel file
#                 df = pd.read_excel(excel_path, sheet_name="Training Calendar", skiprows=1)
#                 if not df.empty:  # Check if the DataFrame is not empty
#                     if (df['Status'] == 'Completed').all():
#                         return True  # If all statuses are 'Completed', return True
#                     else:
#                         return False  # If any status is not 'Completed', return False
#             except PermissionError:
#                 print(f"Permission denied for file: {excel_path}. Skipping...")
#             except Exception as e:
#                 print(f"Error reading {file}: {e}")
#     return False  # Return False if no data found in any Excel file

# def check_skill_record_tc(folder_path: str) -> bool:
#     """
#   check whether any file exists inside 'ESR' or not if the .xlsx file exist then go and read 
#   .xlsx file and then go and check if the sheet named 'Training Calendar' is preent or not
#     if present then go inside 'Training Calendar' sheet name and check if 'Status' named column 
#     contains text like 'Completed' or not
#     """
#     Training_Calendar_data_exists = False
   
#     # Check if the Excel file exists
#     excel_files = [file for file in os.listdir(folder_path) if file.endswith('.xlsx')]
#     if excel_files:
#         for file in excel_files:
#             excel_path = os.path.join(folder_path, file)
#             try:
#                 # Read Excel file
#                 df = pd.read_excel(excel_path, sheet_name="Training Calendar", skiprows=1)
#                 if (df['Status'] == 'Completed').all():
#                     return 'Fully Implemented' 
#                 else:
#                     return 'Partially Implemented'
                
#             except Exception as e:
#                 print(f"Error reading {file}: {e}")
   
#     return False
 
 
# check_skill_record_tc_tool = FunctionTool.from_defaults(fn=check_skill_record_tc)








######################################   YourOpenAIAgent    ########################################



class YourOpenAIAgent:
    def __init__(
        self,
        tools: Sequence[BaseTool] = [],
        llm: OpenAI = OpenAI(temperature=0, model="gpt-3.5-turbo-0613"),
        chat_history: List[ChatMessage] = [],
    ) -> None:
        self._llm = llm
        self._tools = {tool.metadata.name: tool for tool in tools}
        self._chat_history = chat_history

    def reset(self) -> None:
        self._chat_history = []

    def chat(self, message: str) -> str:
        chat_history = self._chat_history
        chat_history.append(ChatMessage(role="user", content=message))
        tools = [
            tool.metadata.to_openai_tool() for _, tool in self._tools.items()
        ]

        ai_message = self._llm.chat(chat_history, tools=tools).message
        additional_kwargs = ai_message.additional_kwargs
        chat_history.append(ai_message)

        tool_calls = ai_message.additional_kwargs.get("tool_calls", None)
        # parallel function calling is now supported
        if tool_calls is not None:
            for tool_call in tool_calls:
                function_message = self._call_function(tool_call)
                chat_history.append(function_message)
                ai_message = self._llm.chat(chat_history).message
                chat_history.append(ai_message)

        return ai_message.content

    def _call_function(self, tool_call: dict) -> ChatMessage:
        id_ = tool_call.id
        function_call = tool_call.function
        tool = self._tools[function_call.name]
        output = tool(**json.loads(function_call.arguments))
        print(f"> Calling tool: {function_call.name}")
        return ChatMessage(
            name=function_call.name,
            content=str(output),
            role="tool",
            additional_kwargs={
                "tool_call_id": id_,
                "name": function_call.name,
            },
        )

llm = OpenAI(model="gpt-3.5-turbo-0613")
agent = OpenAIAgent.from_tools(
    [check_folder_existence_tool, check_file_existence_tool, check_xlsx_file_existence_tool, check_pptx_file_existence_tool, read_pdf_tool, check_sow_heading_tool, check_sdp_existence_tool, check_sdp_heading_tool, check_risk_opportunity_maintained_tool, check_raid_closure_tool], llm=llm, verbose=True
)

#  check_raid_issue_tool,



###############################################  user prompt  ####################################################

def user_prompt(query):
    response = agent.chat(query)
    # explainability=agent.chat(reason)
    return str(response)








# def user_prompt(query,reason):
#     response = agent.chat(query)
#     explainability=agent.chat(reason)
#     return str(response)

# while(True):
#     query=input("Function_response")
#     reason=input("msg content")
#     res = user_prompt(query)
#     msg = user_prompt(reason)
#     print("Agent:",res)
#     print("msg content",msg)



#usr_prompt="check if 'IQA' named folder exist or not inside the Ralph_Lauren project if exist then check whether any file exists inside 'IQA' or not and if file exist check whether it is a .xlsx file or not final if condition satisfies return fully implemnetd in output else partially implemented"
#usr_prompt="check if 'KickOff' named folder exist or not inside the Ralph_Lauren project if exist then check whether any file exists inside 'KickOff' or not if file exist then check it is .pptx file or not final if condition satisfies return fully implemnetd in output else partially implemented "
#usr_prompt="check if 'SoW' named folder exist or not inside the Ralph_Lauren project if exist then check whether any file exists inside 'SoW' or not if the pdf file exist then go and read pdf file and then check is the file contains 'Scope of Work' in it or not final if condition satisfies return fully implemnetd in output else partially implemented."
#usr_prompt="Check if 'SDP' named folder exist or not inside the Ralph_Lauren project if exist then check whether any file exists inside 'SDP' or not if file exist then check it is .docx file or not"
#usr_prompt="Check if 'CAR' named folder exist or not inside the Ralph_Lauren project."
#usr_prompt="Check if 'DAR' named folder exist or not inside the Ralph_Lauren project if exist then check whether any file exists inside 'DAR' or not and if file exist check whether it is a .xlsx file or not"
#usr_prompt="Check if 'RAID Register' named folder exist or not inside the Ralph_Lauren project if exist then check whether any file exists inside 'RAID Register' or not and if file exist check whether it is a .xlsx file, if it is .xlsx file then check if 'Risk Tracker' and 'Opportunity Tracker' sheets contain any data or not if  final condition satisfies return fully implemnetd in output else partially implemented  "
#usr_prompt="Check if 'RAID Register' named folder exist or not inside the Ralph_Lauren if exist then check whether any file exists inside 'RAID Register' or not, if yes then check if it is in .xlsx format or not and then check the excel file with sheet name 'Issues' has data check it is open state or close"
#usr_prompt="check if 'DAR' named folder exist or not inside the Ralph_Lauren project if exist then check whether any file exists inside 'DAR' or not if file exist then check it is .xlsx file or not and if excel file present then search if 'GRID ANALYSIS' named text is present or not inside the excel file if  final condition satisfies return fully implemnetd in output else partially implemented "
# usr_prompt="check if 'SDP' named folder exist or not inside the Ralph_Lauren project if exist then check whether any file exists inside 'SDP' or not if the .docx file exist then go and read .docx file and then check is the file contains 'Hardware, Software and Network Resources' in it or not final if condition satisfies return fully implemnetd in output else partially implemented ."
# usr_prompt= "check if 'ESR' named folder exist or not inside the Ralph_Lauren project if exist then check whether any file exists inside 'ESR' or not if the .xlsx file exist then go and read .xlsx file and then go and check if the sheet named 'Training Calendar' is preent or not if present then go inside 'Training Calendar' sheet name and check if 'Status' named column contains text like 'Completed' or not  final if condition satisfies return fully implemnetd in output else partially implemented ."



# res=user_prompt(usr_prompt)
# print(res)



# def required_list_of_data(query):
#     window_response = query_engine.query(query)
#     return window_response
# query = str(precise_reason)



# explainability_1 = f''' 

# Function_response:can you give me which function you executed now for above task and explain then why you executed or called these function or why did you take these actionss
# Added user message to memory: can you give me which function you executed now for above task and explain then why you executed or called these function or why did you take these actionss

# Agent: Sure! Here are the functions I executed and the reasons behind each action:
 
# 1. 'Folder':This function was called to check file in the folder. I executed this function to 
 
# 2. 'File': This function was called to check file in the file. I executed this function to 
  
# 3. `Format`: This function was called to check format in the file, format can be in form of (.xlsx,.pptx, .docx, pdf). I executed this function to 
 
 
# These actions were taken to address the customer's requests, resolve any issues, and provide a seamless experience for the
# customer.
# msg content:
# ------------------------------------------------------------------------------------
# Function_response:can youn give calling function list
# Added user message to memory: can youn give calling function list
# Agent: Sure! Here is the list of functions that were called:
 
# 1. `check_folder_existence`: This function was called to check file in the folder.
# 2. `check_file_existence`: This function was called to check file in the folder.
# 3. `check_pptx_file_existence`: This function was called to check format of the file(xlsx,docx,pdf) in the folder.
# 4. if all the above conditions are true then ;Fully Implemented or else Partionally Implemented
 
# These functions were called in order to perform the tasks requested by the user and to ensure proper communication and handling of the orders

# query:{reason}'''











# class Agent:
#     def __init__(self):
#         pass
    
#     def chat(self, message):
#         return f"Agent: Received message '{message}'"



# def user_prompt(query, reason):
#     response = agent.chat(query)
#     explainability = agent.chat(reason)
#     data={"response":str(response),"explainability":str(explainability)}
#     return (data)



# while True:
#     query = input("task")
#     reason = "can you give me which function you executed now for above task and explain then why you executed or called these function or why did you take these actions"
#     res = user_prompt(query, reason)  # Pass the agent object to user_prompt
#     print(res)

# explainability_1 = f''' 

# Function_response: can you give me which function you executed now for above task and explain then why you executed or called these function or why did you take these actions
# Added user message to memory: can you give me which function you executed now for above task and explain then why you executed or called these function or why did you take these actions

# Agent: Sure! Here are the functions I executed and the reasons behind each action:
 
# 1. 'Folder': This function was called to check files in the folder. I executed this function to 
#    [checking if the folder exists or not inside the project]

# 2. 'File': This function was called to check files in the file. I executed this function to 
#    [checking if the file exists or not inside the folder]

# 3. 'Format': This function was called to check the format of the file (can be .xlsx, .pptx, .docx, pdf). I executed this function to 
#    [checking if the file is in any particular format or not 

# These actions were taken to address the customer's requests, resolve any issues, and provide a seamless experience for the customer.
# msg content:
# ------------------------------------------------------------------------------------
# Function_response: can you give calling function list
# Added user message to memory: can you give calling function list
# Agent: Sure! Here is the list of functions that were called:
 
# 1. 'check_folder_existence': This function was called to check files in the folder.
# 2. 'check_file_existence': This function was called to check files in the file.
# 3. 'check_pptx_file_existence': This function was called to check the format of the file (xlsx, docx, pdf) in the folder.

 
# These functions were called in order to perform the tasks requested by the user and to ensure proper communication and handling of the orders
# '''

# print(explainability_1)















################################  unzip .docx file ##############################################






# def unzip_docx(docx_file_path: str) -> str:
#     """
#     Unzips a .docx file to a directory with the same name in the same path.
#     Returns the path of the extracted XML file if extraction is successful, 
#     an empty string otherwise.
#     """
#     try:
#         # Extract the directory name without extension
#         output_directory = os.path.splitext(docx_file_path)[0]
#         # Create the output directory if it doesn't exist
#         os.makedirs(output_directory, exist_ok=True)
#         # Unzip the .docx file
#         with zipfile.ZipFile(docx_file_path, 'r') as zip_ref:
#             zip_ref.extractall(output_directory)
        
#         # Find the path of the extracted XML file
#         xml_file_path = os.path.join(output_directory, 'word', 'document.xml')
#         if os.path.isfile(xml_file_path):
#             return xml_file_path
#         else:
#             print("Error: Extracted XML file not found.")
#             return ""
#     except Exception as e:
#         print(f"Error while extracting {docx_file_path}: {e}")
#         return ""

# unzip_docx_tool = FunctionTool.from_defaults(fn=unzip_docx)



# # Define the extract_tables_from_xml function
# def extract_tables_from_xml(xml_file: str, output_directory: str) -> list:
#     """
#     Extracts tables from an XML file and saves them as CSV files.
#     Returns a list of DataFrames representing the extracted tables.
#     """
#     tables = []
#     try:
#         tree = ET.parse(xml_file)
#         root = tree.getroot()
#         ns = {'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
#         table_elements = root.findall('.//w:tbl', namespaces=ns)
#         for i, table_element in enumerate(table_elements, start=1):
#             column_labels = []
#             header_row = table_element.find('.//w:tr', namespaces=ns)
#             if header_row is not None:
#                 for cell_element in header_row.findall('.//w:tc', namespaces=ns):
#                     cell_text = ""
#                     for text_element in cell_element.findall('.//w:t', namespaces=ns):
#                         cell_text += text_element.text if text_element.text else ""
#                     column_labels.append(cell_text)
#             table_data = []
#             for row_element in table_element.findall('.//w:tr', namespaces=ns):
#                 row = []
#                 for cell_element in row_element.findall('.//w:tc', namespaces=ns):
#                     cell_text = ""
#                     for text_element in cell_element.findall('.//w:t', namespaces=ns):
#                         cell_text += text_element.text if text_element.text else ""
#                     row.append(cell_text)
#                 table_data.append(row)
#             df = pd.DataFrame(table_data, columns=column_labels)
#             df = df.iloc[1:]
#             df.reset_index(drop=True, inplace=True)
#             folder_name = os.path.join(output_directory, 'tables_folder')
#             os.makedirs(folder_name, exist_ok=True)
#             csv_file_name = os.path.join(folder_name, f"table_{i}.csv")
#             df.to_csv(csv_file_name, index=False)
#             tables.append(df)
#     except Exception as e:
#         print(f"Error while extracting tables from {xml_file}: {e}")
#     return tables


# extract_tables_from_xml_tool = FunctionTool.from_defaults(fn=extract_tables_from_xml)


# # Define the check_csv_files function
# def check_csv_files_null(folder_path: str) -> str:
#     """
#     Checks CSV files in the specified folder for null values.
#     Returns 'Partially Implemented' if any CSV file contains null values,
#     'Fully Implemented' otherwise.
#     """
#     file_statuses = []
#     for file_name in os.listdir(folder_path):
#         if file_name.endswith('.csv'):
#             file_path = os.path.join(folder_path, file_name)
#             df = pd.read_csv(file_path)
#             has_null = df.isnull().values.any()
#             file_statuses.append({'File Name': file_name, 'Has Null Values': has_null})
#     if any(status['Has Null Values'] for status in file_statuses):
#         return "Partially Implemented"
#     else:
#         return "Fully Implemented"

 
 
# check_csv_files_null_tool = FunctionTool.from_defaults(fn=check_csv_files_null)



#############################################################################################################################################################################  








