import os
import openai
from llama_index import SimpleDirectoryReader
from llama_index.llms import OpenAI
from llama_index.embeddings import OpenAIEmbedding
from llama_index.node_parser import SentenceWindowNodeParser
from llama_index import VectorStoreIndex
from llama_index.postprocessor import MetadataReplacementPostProcessor
from llama_index import ServiceContext
# Set your OpenAI API key
api_key = "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"
openai.api_key = api_key

# Load documents from the specified directory
documents = SimpleDirectoryReader(r"C:\Users\vgarlapati\Downloads\RL_Project1(old)\RL_Project1\Ralph_Lauren_v2\Ralph_Lauren\ask_hr").load_data()

# Create the sentence window node parser with default settings
node_parser = SentenceWindowNodeParser.from_defaults(
    window_size=10,
    window_metadata_key="window",
    original_text_metadata_key="original_text",
)

# Initialize the language model and embedding model

llm = OpenAI(model="gpt-3.5-turbo", temperature=0)
embed_model = OpenAIEmbedding()
ctx = ServiceContext.from_defaults(
    llm=llm,
    embed_model=embed_model,
    node_parser=node_parser,
)

# Parse the nodes from the documents
nodes = node_parser.get_nodes_from_documents(documents)

# Create the vector store index
sentence_index = VectorStoreIndex(nodes, service_context=ctx)

# Create the query engine with the specified settings
query_engine = sentence_index.as_query_engine(
    similarity_top_k=10,
    node_postprocessors=[
        MetadataReplacementPostProcessor(target_metadata_key="window")
    ],
)

# Prompt the user for input in the terminal
query = input("How many national/festival holidays does Prolifics observe every calendar year?: ")

# Perform the query and print the response
window_response = query_engine.query(query)
print(f"Response: {window_response}")
