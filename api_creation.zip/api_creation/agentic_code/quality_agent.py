import json
from typing import Sequence, List
 
from llama_index.llms import OpenAI, ChatMessage
from llama_index.tools import BaseTool, FunctionTool
 
 
import nest_asyncio
import os
 
from llama_index.agent import OpenAIAgent
from llama_index.llms import OpenAI
 
import csv
import os
import uuid
import requests
import zipfile
import xml.etree.ElementTree as ET
 
#from check_review import desc_compare
 
os.environ["OPENAI_API_KEY"] = "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"
nest_asyncio.apply()
 
 
import os
import pdfplumber
import pandas as pd
 
 
 
def check_folder_existence(folder_name: str) -> str:
    """
    Check whether a folder with the given name exists inside the root folder path and its subdirectories.
    Returns the path of the folder if found, otherwise returns "not found".
    """
   
    root_name = "Ralph_Lauren_v2"
    default_path = r'C:\Users\vgarlapati\Downloads\RL_Project1(old)\RL_Project1'
    root_folder_path = os.path.join(default_path, root_name)
   
    # Walk through the directory tree starting from the root folder
    for root, dirs, files in os.walk(root_folder_path):
        if folder_name in dirs:
            return os.path.join(root, folder_name)
    return "Folder '{}' not found inside {} and its subdirectories.".format(folder_name, root_folder_path)
 
 
check_folder_existence_tool = FunctionTool.from_defaults(fn=check_folder_existence)
 
 
def check_file_existence(folder_path: str) -> bool:
    """
    Check if any file exists inside the given folder or its subdirectories.
    Returns True if at least one file exists, otherwise False.
    """
    # Walk through the directory tree starting from the given folder
    for root, dirs, files in os.walk(folder_path):
        if files:
            return True  # At least one file exists
    return False  # No file exists
 
 
check_file_existence_tool =FunctionTool.from_defaults(fn=check_file_existence)
 
 
#############################################################  IQA Report  ########################################################################
 
def check_xlsx_file_existence(folder_path: str) -> str:
    """
    Check if a .xlsx file exists inside the given folder or its subdirectories.
    Returns 'Fully Implemented' if an .xlsx file exists, otherwise 'Partially Implemented'.
    """
    # Walk through the directory tree starting from the given folder
    for root, dirs, files in os.walk(folder_path):
        for file in files:
            if file.endswith('.xlsx'):
                return True
    return False
 
 
check_xlsx_file_existence_tool = FunctionTool.from_defaults(fn=check_xlsx_file_existence)
 
 
#################################################  Kick-off ppt  ##############################################################
 
 
def check_pptx_file_existence(folder_path: str) -> str:
    """
    Check if a .pptx file exists inside the given folder or its subdirectories.
    Returns 'Fully Implemented' if an .pptx file exists, otherwise 'Partially Implemented'.
    """
   
    for root, dirs, files in os.walk(folder_path):
        for file in files:
            if file.endswith('.pptx'):
                return True
    return False
 
 
check_pptx_file_existence_tool = FunctionTool.from_defaults(fn=check_pptx_file_existence)
 
 
 
##################################################### sow headings  #################################################################
 
def read_pdf(folder_path: str) -> bool:
    """
    Check if a .docx file exists inside the given folder or its subdirectories.
    Returns True if a .docx file exists, otherwise False.
    """
    # Walk through the directory tree starting from the given folder
    for root, dirs, files in os.walk(folder_path):
        for file in files:
            if file.endswith('.pdf'):
                return True
    return False
 
read_pdf_tool  = FunctionTool.from_defaults(fn=read_pdf)
 
 
 
 
 
def check_sow_heading(folder_path: str) -> bool:
    """
    Check if the 'Scope of Work' heading is present in any PDF file inside the given folder or its subdirectories.
    Returns True if the heading is found, otherwise False.
    """
    # Walk through the directory tree starting from the given folder
    for root, dirs, files in os.walk(folder_path):
        for file_name in files:
            if file_name.endswith('.pdf'):
                file_path = os.path.join(root, file_name)
                with pdfplumber.open(file_path) as pdf:
                    for page in pdf.pages:
                        text = page.extract_text()
                        if 'Human Resources' in text:
                            return True
    return False
 
check_sow_heading_tool  = FunctionTool.from_defaults(fn=check_sow_heading)

################################################  sdp present ####################################
# # Function to extract text from PDFsHuman Resources


# def extract_text_from_pdfs(folder_path: str) -> str:
#     extracted_text = ""
#     for root, dirs, files in os.walk(folder_path):
#         for file_name in files:
#             if file_name.endswith('.pdf'):
#                 file_path = os.path.join(root, file_name)
#                 with pdfplumber.open(file_path) as pdf:
#                     for page in pdf.pages:
#                         extracted_text += page.extract_text() + "\n"
#     return extracted_text

# extract_text_from_pdfs_tool = FunctionTool.from_defaults(fn=extract_text_from_pdfs)
################################################  sdp present ####################################

# def extract_text_from_excels(folder_path: str) -> str:
#     extracted_text = ""
#     for root, dirs, files in os.walk(folder_path):
#         for file_name in files:
#             if file_name.endswith('.xlsx') or file_name.endswith('.xls'):
#                 file_path = os.path.join(root, file_name)
#                 try:
#                     df = pd.read_excel(file_path, sheet_name=None)
#                     for sheet_name, sheet_df in df.items():
#                         extracted_text += f"Sheet: {sheet_name}\n"
#                         extracted_text += sheet_df.to_string() + "\n"
#                 except Exception as e:
#                     print(f"Error reading {file_path}: {e}")
#     return extracted_text
# extract_text_from_excels_tool = FunctionTool.from_defaults(fn=extract_text_from_excels)

 
################################################  sdp present ####################################
 
 
 
def check_sdp_existence(folder_path: str) -> bool:
    """
    Check if a .docx file exists inside the given folder or its subdirectories.
    Returns True if a .docx file exists, otherwise False.
    """
    # Walk through the directory tree starting from the given folder
    for root, dirs, files in os.walk(folder_path):
        for file in files:
            if file.endswith('.docx'):
                return True
    return False
 
check_sdp_existence_tool  = FunctionTool.from_defaults(fn=check_sdp_existence)
 
 
import os
from docx import Document
 
def check_sdp_heading(folder_path: str) -> bool:
    """
    Check if the 'Hardware, Software and Network Resources' heading is present in any DOCX file inside the given folder or its subdirectories.
    Returns True if the heading is found, otherwise False.
    """
    # Walk through the directory tree starting from the given folder
    for root, dirs, files in os.walk(folder_path):
        for file_name in files:
            if file_name.endswith('.docx'):
                file_path = os.path.join(root, file_name)
                doc = Document(file_path)
                for paragraph in doc.paragraphs:
                    if 'Hardware, Software and Network Resources' in paragraph.text:
                        return True
    return False
 
check_sdp_heading_tool = FunctionTool.from_defaults(fn=check_sdp_heading)
 
 
##########################################  risk_opportunity_maintained  #################################
 
 
 
def check_risk_opportunity_maintained(folder_path: str) -> bool:
    """
    Check if 'Risk Tracker' and 'Opportunity Tracker' sheets contain any data in the given Excel file.
    Returns True indicating whether each sheet contains data, otherwise False.
    """
    risk_data_exists = False
    opportunity_data_exists = False
   
    # Check if the Excel file exists
    excel_files = [file for file in os.listdir(folder_path) if file.endswith('.xlsx')]
    if excel_files:
        for file in excel_files:
            excel_path = os.path.join(folder_path, file)
            try:
                # Read Excel file
                xl = pd.ExcelFile(excel_path)
                if 'Risk Tracker' in xl.sheet_names:
                    risk_df = xl.parse('Risk Tracker')
                    if not risk_df.empty:
                        risk_data_exists = True
                if 'Opportunity Tracker' in xl.sheet_names:
                    opportunity_df = xl.parse('Opportunity Tracker')
                    if not opportunity_df.empty:
                        opportunity_data_exists = True
            except Exception as e:
                print(f"Error reading {file}: {e}")
   
    if risk_data_exists and opportunity_data_exists == True:
        return True
    else:
        return False
 
 
 
check_risk_opportunity_maintained_tool = FunctionTool.from_defaults(fn=check_risk_opportunity_maintained)
 
 
 
 
 
####################################   check_raid_issue   ##################################################
 
 
 
def check_raid_issue(folder_path: str) -> bool:
    """
    Check if 'Issues' sheets contain any data in the given Excel file.
    Returns True indicating whether each sheet contains data check it is open state or close, otherwise False.
    """
    issues_data_exists = False
   
    # Check if the Excel file exists
    excel_files = [file for file in os.listdir(folder_path) if file.endswith('.xlsx')]
    if excel_files:
        for file in excel_files:
            excel_path = os.path.join(folder_path, file)
            try:
                # Read Excel file
                xl = pd.ExcelFile(excel_path)
                if 'Issues' in xl.sheet_names:
                    issues_data_exists = xl.parse('Issues')
                    if not issues_data_exists.empty:
                        issues_data_exists = True
            except Exception as e:
                print(f"Error reading {file}: {e}")
   
    if issues_data_exists == True:
        return True
    else:
        return False
 
 
check_raid_issue_tool = FunctionTool.from_defaults(fn=check_raid_issue)
 
 
 
 
 
 
#####################################  dar analysis  #############################
 
 
#  sk-proj-kv3jLkkws7NLOeYlQi0mT3BlbkFJ9ajCeg9W6K0NUnVDZuST
 
 
 
def get_sheet_names_dar(folder_path: str) -> list:
    """
    Returns a list of sheet names from the first found .xlsx file within the given folder or its subdirectories.
    """
    try:
        sheet_names = []
       
        # Walk through the directory tree starting from the given folder
        for root, dirs, files in os.walk(folder_path):
            for file_name in files:
                if file_name.endswith('.xlsx'):
                    excel_file = os.path.join(root, file_name)
                    # Attempt to read the Excel file
                    try:
                        df = pd.read_excel(excel_file, sheet_name=None)
                        sheet_names.extend(df.keys())
                    except Exception as e:
                        print(f"Error occurred while reading Excel file '{excel_file}': {e}")
                        continue
                    break  # Stop after reading the first Excel file
            if sheet_names:
                break
 
        return sheet_names
       
    except Exception as e:
        print(f"Error occurred while processing folder '{folder_path}': {e}")
        return []
 
 
get_sheet_names_dar_tool = FunctionTool.from_defaults(fn=get_sheet_names_dar)
 
 
 
def check_sheet_for_text_dar(folder_path: str) -> str:
    """
    Checks if the specified text is present in any of the sheets in the first found .xlsx file within the given folder or its subdirectories.
    Returns 'Fully Implemented' if found, otherwise 'Partially Implemented'.
    """
    try:
        # Define the text to search for
        target_text = 'GRID ANALYSIS'
       
        # Walk through the directory tree starting from the given folder
        for root, dirs, files in os.walk(folder_path):
            for file_name in files:
                if file_name.endswith('.xlsx'):
                    excel_file = os.path.join(root, file_name)
                    # Attempt to read the Excel file
                    try:
                        df = pd.read_excel(excel_file, sheet_name=None)
                    except Exception as e:
                        print(f"Error occurred while reading Excel file '{excel_file}': {e}")
                        continue
 
                    # Check each sheet for the target text
                    for sheet_name, sheet_df in df.items():
                        if any(sheet_df.apply(lambda row: target_text in ' '.join(map(str, row)), axis=1)):
                            return 'Fully Implemented'
        return 'Partially Implemented'
       
    except Exception as e:
        print(f"Error occurred while processing folder '{folder_path}': {e}")
        return 'Partially Implemented'
 
 
 
check_sheet_for_text_dar_tool = FunctionTool.from_defaults(fn=check_sheet_for_text_dar)
 
 
 
 
 
 
#####################################  ESR TC #########################################
 
 
 
 
# def check_skill_record_tc(folder_path: str) -> bool:
#     """
#      check whether any file exists inside 'ESR' or not if the .xlsx file exist then go and read
#    .xlsx file and then go and check if the sheet named 'Training Calendar' is preent or not
#      if present then go inside 'Training Calendar' sheet name and check if 'Status' named column
#    contains text like 'Completed' or not
#     """
#     # Check if any Excel file exists
#     excel_files = [file for file in os.listdir(folder_path) if file.endswith('.xlsx')]
#     if excel_files:
#         for file in excel_files:
#             excel_path = os.path.join(folder_path, file)
#             try:
#                 # Read Excel file
#                 df = pd.read_excel(excel_path, sheet_name="Training Calendar", skiprows=1)
#                 if not df.empty:  # Check if the DataFrame is not empty
#                     if (df['Status'] == 'Completed').all():
#                         return True  # If all statuses are 'Completed', return True
#                     else:
#                         return False  # If any status is not 'Completed', return False
#             except PermissionError:
#                 print(f"Permission denied for file: {excel_path}. Skipping...")
#             except Exception as e:
#                 print(f"Error reading {file}: {e}")
#     return False  # Return False if no data found in any Excel file
 
# def check_skill_record_tc(folder_path: str) -> bool:
#     """
#   check whether any file exists inside 'ESR' or not if the .xlsx file exist then go and read
#   .xlsx file and then go and check if the sheet named 'Training Calendar' is preent or not
#     if present then go inside 'Training Calendar' sheet name and check if 'Status' named column
#     contains text like 'Completed' or not
#     """
#     Training_Calendar_data_exists = False
   
#     # Check if the Excel file exists
#     excel_files = [file for file in os.listdir(folder_path) if file.endswith('.xlsx')]
#     if excel_files:
#         for file in excel_files:
#             excel_path = os.path.join(folder_path, file)
#             try:
#                 # Read Excel file
#                 df = pd.read_excel(excel_path, sheet_name="Training Calendar", skiprows=1)
#                 if (df['Status'] == 'Completed').all():
#                     return 'Fully Implemented'
#                 else:
#                     return 'Partially Implemented'
               
#             except Exception as e:
#                 print(f"Error reading {file}: {e}")
   
#     return False
 
 
# check_skill_record_tc_tool = FunctionTool.from_defaults(fn=check_skill_record_tc)
 
 
 
 
 
 
 
 
######################################   YourOpenAIAgent    ########################################
 
 
 
class YourOpenAIAgent:
    def __init__(
        self,
        tools: Sequence[BaseTool] = [],
        llm: OpenAI = OpenAI(temperature=0, model="gpt-3.5-turbo-0613"),
        chat_history: List[ChatMessage] = [],
    ) -> None:
        self._llm = llm
        self._tools = {tool.metadata.name: tool for tool in tools}
        self._chat_history = chat_history
 
    def reset(self) -> None:
        self._chat_history = []
 
    def chat(self, message: str) -> str:
        chat_history = self._chat_history
        chat_history.append(ChatMessage(role="user", content=message))
        tools = [
            tool.metadata.to_openai_tool() for _, tool in self._tools.items()
        ]
 
        ai_message = self._llm.chat(chat_history, tools=tools).message
        additional_kwargs = ai_message.additional_kwargs
        chat_history.append(ai_message)
 
        tool_calls = ai_message.additional_kwargs.get("tool_calls", None)
        # parallel function calling is now supported
        if tool_calls is not None:
            for tool_call in tool_calls:
                function_message = self._call_function(tool_call)
                chat_history.append(function_message)
                ai_message = self._llm.chat(chat_history).message
                chat_history.append(ai_message)
 
        return ai_message.content
 
    def _call_function(self, tool_call: dict) -> ChatMessage:
        id_ = tool_call.id
        function_call = tool_call.function
        tool = self._tools[function_call.name]
        output = tool(**json.loads(function_call.arguments))
        print(f"> Calling tool: {function_call.name}")
        return ChatMessage(
            name=function_call.name,
            content=str(output),
            role="tool",
            additional_kwargs={
                "tool_call_id": id_,
                "name": function_call.name,
            },
        )
 
llm = OpenAI(model="gpt-3.5-turbo-0613")
agent = OpenAIAgent.from_tools(
    [check_folder_existence_tool, check_file_existence_tool, check_xlsx_file_existence_tool, check_pptx_file_existence_tool,read_pdf_tool], llm=llm, verbose=True)
# ), extract_text_from_pdfs_tool, extract_text_from_excels_tool
# agent = OpenAIAgent.from_tools(
#     [check_folder_existence_tool, check_file_existence_tool, check_xlsx_file_existence_tool, check_pptx_file_existence_tool, read_pdf_tool, check_sow_heading_tool, check_sdp_existence_tool, check_sdp_heading_tool, check_risk_opportunity_maintained_tool, check_raid_issue_tool,get_sheet_names_dar_tool, check_sheet_for_text_dar_tool], llm=llm, verbose=True
# )
 
 
 
 
 
###############################################  user prompt  ####################################################
 
 
 
def user_prompt(query):
    response = agent.chat(query)
    return str(response)
 
 
 
################################  unzip .docx file ##############################################
 
 
 
 
 
 
# def unzip_docx(docx_file_path: str) -> str:
#     """
#     Unzips a .docx file to a directory with the same name in the same path.
#     Returns the path of the extracted XML file if extraction is successful,
#     an empty string otherwise.
#     """
#     try:
#         # Extract the directory name without extension
#         output_directory = os.path.splitext(docx_file_path)[0]
#         # Create the output directory if it doesn't exist
#         os.makedirs(output_directory, exist_ok=True)
#         # Unzip the .docx file
#         with zipfile.ZipFile(docx_file_path, 'r') as zip_ref:
#             zip_ref.extractall(output_directory)
       
#         # Find the path of the extracted XML file
#         xml_file_path = os.path.join(output_directory, 'word', 'document.xml')
#         if os.path.isfile(xml_file_path):
#             return xml_file_path
#         else:
#             print("Error: Extracted XML file not found.")
#             return ""
#     except Exception as e:
#         print(f"Error while extracting {docx_file_path}: {e}")
#         return ""
 
# unzip_docx_tool = FunctionTool.from_defaults(fn=unzip_docx)
 
 
 
# # Define the extract_tables_from_xml function
# def extract_tables_from_xml(xml_file: str, output_directory: str) -> list:
#     """
#     Extracts tables from an XML file and saves them as CSV files.
#     Returns a list of DataFrames representing the extracted tables.
#     """
#     tables = []
#     try:
#         tree = ET.parse(xml_file)
#         root = tree.getroot()
#         ns = {'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
#         table_elements = root.findall('.//w:tbl', namespaces=ns)
#         for i, table_element in enumerate(table_elements, start=1):
#             column_labels = []
#             header_row = table_element.find('.//w:tr', namespaces=ns)
#             if header_row is not None:
#                 for cell_element in header_row.findall('.//w:tc', namespaces=ns):
#                     cell_text = ""
#                     for text_element in cell_element.findall('.//w:t', namespaces=ns):
#                         cell_text += text_element.text if text_element.text else ""
#                     column_labels.append(cell_text)
#             table_data = []
#             for row_element in table_element.findall('.//w:tr', namespaces=ns):
#                 row = []
#                 for cell_element in row_element.findall('.//w:tc', namespaces=ns):
#                     cell_text = ""
#                     for text_element in cell_element.findall('.//w:t', namespaces=ns):
#                         cell_text += text_element.text if text_element.text else ""
#                     row.append(cell_text)
#                 table_data.append(row)
#             df = pd.DataFrame(table_data, columns=column_labels)
#             df = df.iloc[1:]
#             df.reset_index(drop=True, inplace=True)
#             folder_name = os.path.join(output_directory, 'tables_folder')
#             os.makedirs(folder_name, exist_ok=True)
#             csv_file_name = os.path.join(folder_name, f"table_{i}.csv")
#             df.to_csv(csv_file_name, index=False)
#             tables.append(df)
#     except Exception as e:
#         print(f"Error while extracting tables from {xml_file}: {e}")
#     return tables
 
 
# extract_tables_from_xml_tool = FunctionTool.from_defaults(fn=extract_tables_from_xml)
 
 
# # Define the check_csv_files function
# def check_csv_files_null(folder_path: str) -> str:
#     """
#     Checks CSV files in the specified folder for null values.
#     Returns 'Partially Implemented' if any CSV file contains null values,
#     'Fully Implemented' otherwise.
#     """
#     file_statuses = []
#     for file_name in os.listdir(folder_path):
#         if file_name.endswith('.csv'):
#             file_path = os.path.join(folder_path, file_name)
#             df = pd.read_csv(file_path)
#             has_null = df.isnull().values.any()
#             file_statuses.append({'File Name': file_name, 'Has Null Values': has_null})
#     if any(status['Has Null Values'] for status in file_statuses):
#         return "Partially Implemented"
#     else:
#         return "Fully Implemented"
 
 
 
# check_csv_files_null_tool = FunctionTool.from_defaults(fn=check_csv_files_null)
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
#usr_prompt="check if 'IQA' named folder exist or not inside the Ralph_Lauren project if exist then check whether any file exists inside 'IQA' or not and if file exist check whether it is a .xlsx file or not final if condition satisfies return fully implemnetd in output else partially implemented"
#usr_prompt="check if 'KickOff' named folder exist or not inside the Ralph_Lauren project if exist then check whether any file exists inside 'KickOff' or not if file exist then check it is .pptx file or not final if condition satisfies return fully implemnetd in output else partially implemented "
#usr_prompt="check if 'SoW' named folder exist or not inside the Ralph_Lauren project if exist then check whether any file exists inside 'SoW' or not if the pdf file exist then go and read pdf file and then check is the file contains 'Scope of Work' in it or not final if condition satisfies return fully implemnetd in output else partially implemented."
#usr_prompt="Check if 'SDP' named folder exist or not inside the Ralph_Lauren project if exist then check whether any file exists inside 'SDP' or not if file exist then check it is .docx file or not"
#usr_prompt="Check if 'CAR' named folder exist or not inside the Ralph_Lauren project."
#usr_prompt="Check if 'DAR' named folder exist or not inside the Ralph_Lauren project if exist then check whether any file exists inside 'DAR' or not and if file exist check whether it is a .xlsx file or not"
#usr_prompt="Check if 'RAID Register' named folder exist or not inside the Ralph_Lauren project if exist then check whether any file exists inside 'RAID Register' or not and if file exist check whether it is a .xlsx file, if it is .xlsx file then check if 'Risk Tracker' and 'Opportunity Tracker' sheets contain any data or not if  final condition satisfies return fully implemnetd in output else partially implemented  "
#usr_prompt="Check if 'RAID Register' named folder exist or not inside the Ralph_Lauren if exist then check whether any file exists inside 'RAID Register' or not, if yes then check if it is in .xlsx format or not and then check the excel file with sheet name 'Issues' has data check it is open state or close"
#usr_prompt="check if 'DAR' named folder exist or not inside the Ralph_Lauren project if exist then check whether any file exists inside 'DAR' or not if file exist then check it is .xlsx file or not and if excel file present then search if 'GRID ANALYSIS' named text is present or not inside the excel file if  final condition satisfies return fully implemnetd in output else partially implemented "
# usr_prompt="check if 'SDP' named folder exist or not inside the Ralph_Lauren project if exist then check whether any file exists inside 'SDP' or not if the .docx file exist then go and read .docx file and then check is the file contains 'Hardware, Software and Network Resources' in it or not final if condition satisfies return fully implemnetd in output else partially implemented ."
# usr_prompt= "check if 'ESR' named folder exist or not inside the Ralph_Lauren project if exist then check whether any file exists inside 'ESR' or not if the .xlsx file exist then go and read .xlsx file and then go and check if the sheet named 'Training Calendar' is preent or not if present then go inside 'Training Calendar' sheet name and check if 'Status' named column contains text like 'Completed' or not  final if condition satisfies return fully implemnetd in output else partially implemented ."
 
 
 
# res=user_prompt(usr_prompt)
# print(res)
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
################################  unzip .docx file ##############################################
 
 
 
 
 
 
# def unzip_docx(docx_file_path: str) -> str:
#     """
#     Unzips a .docx file to a directory with the same name in the same path.
#     Returns the path of the extracted XML file if extraction is successful,
#     an empty string otherwise.
#     """
#     try:
#         # Extract the directory name without extension
#         output_directory = os.path.splitext(docx_file_path)[0]
#         # Create the output directory if it doesn't exist
#         os.makedirs(output_directory, exist_ok=True)
#         # Unzip the .docx file
#         with zipfile.ZipFile(docx_file_path, 'r') as zip_ref:
#             zip_ref.extractall(output_directory)
       
#         # Find the path of the extracted XML file
#         xml_file_path = os.path.join(output_directory, 'word', 'document.xml')
#         if os.path.isfile(xml_file_path):
#             return xml_file_path
#         else:
#             print("Error: Extracted XML file not found.")
#             return ""
#     except Exception as e:
#         print(f"Error while extracting {docx_file_path}: {e}")
#         return ""
 
# unzip_docx_tool = FunctionTool.from_defaults(fn=unzip_docx)
 
 
 
# # Define the extract_tables_from_xml function
# def extract_tables_from_xml(xml_file: str, output_directory: str) -> list:
#     """
#     Extracts tables from an XML file and saves them as CSV files.
#     Returns a list of DataFrames representing the extracted tables.
#     """
#     tables = []
#     try:
#         tree = ET.parse(xml_file)
#         root = tree.getroot()
#         ns = {'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
#         table_elements = root.findall('.//w:tbl', namespaces=ns)
#         for i, table_element in enumerate(table_elements, start=1):
#             column_labels = []
#             header_row = table_element.find('.//w:tr', namespaces=ns)
#             if header_row is not None:
#                 for cell_element in header_row.findall('.//w:tc', namespaces=ns):
#                     cell_text = ""
#                     for text_element in cell_element.findall('.//w:t', namespaces=ns):
#                         cell_text += text_element.text if text_element.text else ""
#                     column_labels.append(cell_text)
#             table_data = []
#             for row_element in table_element.findall('.//w:tr', namespaces=ns):
#                 row = []
#                 for cell_element in row_element.findall('.//w:tc', namespaces=ns):
#                     cell_text = ""
#                     for text_element in cell_element.findall('.//w:t', namespaces=ns):
#                         cell_text += text_element.text if text_element.text else ""
#                     row.append(cell_text)
#                 table_data.append(row)
#             df = pd.DataFrame(table_data, columns=column_labels)
#             df = df.iloc[1:]
#             df.reset_index(drop=True, inplace=True)
#             folder_name = os.path.join(output_directory, 'tables_folder')
#             os.makedirs(folder_name, exist_ok=True)
#             csv_file_name = os.path.join(folder_name, f"table_{i}.csv")
#             df.to_csv(csv_file_name, index=False)
#             tables.append(df)
#     except Exception as e:
#         print(f"Error while extracting tables from {xml_file}: {e}")
#     return tables
 
 
# extract_tables_from_xml_tool = FunctionTool.from_defaults(fn=extract_tables_from_xml)
 
 
# # Define the check_csv_files function
# def check_csv_files_null(folder_path: str) -> str:
#     """
#     Checks CSV files in the specified folder for null values.
#     Returns 'Partially Implemented' if any CSV file contains null values,
#     'Fully Implemented' otherwise.
#     """
#     file_statuses = []
#     for file_name in os.listdir(folder_path):
#         if file_name.endswith('.csv'):
#             file_path = os.path.join(folder_path, file_name)
#             df = pd.read_csv(file_path)
#             has_null = df.isnull().values.any()
#             file_statuses.append({'File Name': file_name, 'Has Null Values': has_null})
#     if any(status['Has Null Values'] for status in file_statuses):
#         return "Partially Implemented"
#     else:
#         return "Fully Implemented"
 
 
 
# check_csv_files_null_tool = FunctionTool.from_defaults(fn=check_csv_files_null)
 

 
 
 
 
 
 
 